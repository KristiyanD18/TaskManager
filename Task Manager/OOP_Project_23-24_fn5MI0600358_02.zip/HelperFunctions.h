#pragma once
#include "MyString.h"
#include "ctime"
bool isDigit(char s);
unsigned getDigitFromChar(char s);
unsigned getNumFromStr(const MyString& str);