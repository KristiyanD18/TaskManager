#pragma once
#include "User.h"

class CollabUser : public User
{


};

